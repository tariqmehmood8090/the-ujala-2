# Project memory

## Product intent & audience

- School/education administration app with a "Print Notice" feature for generating formal notices.
- Bilingual audience: English and Urdu speakers; notices must render correctly in either language.
- Admins can configure default notice text templates via a dedicated Notice Settings screen.

## Brand personality & voice

- Clear, formal, admin-friendly tone for notice text.
- Labels and UI prompts remain in English; generated notice content localizes to the chosen language.

## Visual design & UX direction

- Language selection surfaced inline within the Print Notice flow (explicit choice before generation), not buried in global settings.
- Urdu notices require RTL layout direction and appropriate font handling; English stays LTR.
- Preview should reflect the selected language live (heading, message direction, sign-off, button labels).
- Settings screen uses tabbed/sectioned layout to separate English vs Urdu templates per notice type.
- Continue using Tailwind CSS + Lucide React icons and the `@/` path alias per `.bolt/prompt`.

## Decisions, constraints & rationale

- Language options scoped to Print Notice only (English, Urdu) rather than a global language toggle.
- Notice generation gated on explicit language choice so output directionality and copy are predictable.
- No new UI/icon packages introduced; existing stack (React + Tailwind + Lucide) used.
- Notice Settings screen added as a dedicated route/page accessible from sidebar and School Settings link.
- Four default templates maintained: Fee clearance reminder (English + Urdu), Warning notice (English + Urdu).
- Templates support `{{student_name}}` and `{{school_name}}` placeholders for dynamic substitution.
- Saved template edits automatically propagate to future quick-action notices and printed notices.
- Template strings stored in-code (no i18n framework); no external persistence layer inferred beyond React state.

## Open questions & assumptions

- Urdu font family for print fidelity is unspecified; assumed to use a system/web font that supports Nastaliq/Naskh unless overridden.
- Whether to persist the last-selected language as a default for future notices is undetermined.
- Template persistence mechanism assumed to be React state only; backend/localStorage persistence not confirmed.
- Whether admins can reset templates to defaults (restore factory templates) is undetermined.